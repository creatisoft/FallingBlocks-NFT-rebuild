using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Paddle : MonoBehaviour {


    Rigidbody2D paddleRigidbody;
    public float paddleSpeed = 5.0f;

    //int points = 0;

    //public FingerMovement fingerMovementInput;


    // Start is called before the first frame update
    void Start() {

        paddleRigidbody = gameObject.GetComponent<Rigidbody2D>();

    }

    // Update is called once per frame
    void Update() {


        //clamp player position
        //Vector3 myPosition = gameObject.transform.position;
        //myPosition.x = Mathf.Clamp(myPosition.x, -7, 7);
        //transform.position = myPosition;

        

        if (Input.GetKey(KeyCode.D)) {

            paddleRigidbody.AddForce(Vector2.right * paddleSpeed, ForceMode2D.Impulse);
            //transform.Translate(Vector2.right * 1.2f * Time.deltaTime);

		}

        if (Input.GetKey(KeyCode.A)) {


            //paddleRigidbody.MovePosition( (transform.position + Vector3.left) * Time.deltaTime * paddleSpeed);


            paddleRigidbody.AddForce(Vector2.left * paddleSpeed, ForceMode2D.Impulse);

            //transform.Translate(Vector2.left * 1.2f * Time.deltaTime);

        }




        /*
        Vector2 testReturn = fingerMovementInput.PaddlePositionReturn();

        //fingerInput code
        //transform.Translate(Vector2.right * (testReturn.x * 0.08f)* Time.deltaTime);
        paddleRigidbody.AddForce(Vector2.right * (testReturn.x), ForceMode2D.Force);
        */


    }

	private void OnCollisionEnter2D(Collision2D collision) {


         /*if(collision.gameObject.tag == "Box1") {


            Debug.Log("box 1 has landed on paddle...");
            

		}
        if (collision.gameObject.tag == "Box2") {

            Debug.Log("box 2 has landed paddle...");

        }
        if (collision.gameObject.tag == "Box3") {

            Debug.Log("box 3 has landed paddle...");

        }
        if (collision.gameObject.tag == "Box4") {

            Debug.Log("box 4 has landed paddle...");

        }*/


    }
}
