using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class BoxSpawner : MonoBehaviour {



    public int boxPoints = 0;


    public GameObject[] boxObjects = new GameObject[32];
    public GameObject[] Boxes;
    int randomBox = 0;

    public TextMeshProUGUI scoreSystem; 

    // Start is called before the first frame update
    void Start() {


        InvokeRepeating("SpawnBox", 2.5f, 3.5f);
        InvokeRepeating("LocationSpawn", 1.5f, 1.5f);


        Boxes = new GameObject[32];

        for(int i = 0; i < Boxes.Length; i++) {

            Boxes[i] = (GameObject)Instantiate(boxObjects[i]);
            Boxes[i].transform.position = boxObjects[i].transform.position;
            Boxes[i].SetActive(false);

		}


    }

    void LocationSpawn() {

        transform.position = new Vector3(Random.Range(-4.5f, 4.5f), 3.47f);

	}

    void SpawnBox(){


        for(int i = 0; i < Boxes.Length; i++) {

            if (Boxes[i].activeInHierarchy == false && Boxes[i].gameObject.tag == "Box1") {

                scoreSystem.text = "Points: " + (boxPoints += 1);

                Debug.Log(boxPoints);
                Boxes[i].transform.position = transform.position;
                Boxes[i].SetActive(true);
                break;


            }
            if (Boxes[i].activeInHierarchy == false && Boxes[i].gameObject.tag == "Box2") {

                scoreSystem.text = "Points: " + (boxPoints += 2);

                Debug.Log(boxPoints);

                Boxes[i].transform.position = transform.position;
                Boxes[i].SetActive(true);
                break;


            }
            if (Boxes[i].activeInHierarchy == false && Boxes[i].gameObject.tag == "Box3") {

                scoreSystem.text = "Points: " + (boxPoints += 3);

                Debug.Log(boxPoints);

                Boxes[i].transform.position = transform.position;
                Boxes[i].SetActive(true);
                break;


            }
            if (Boxes[i].activeInHierarchy == false && Boxes[i].gameObject.tag == "Box4") {


                scoreSystem.text = "Points: " + (boxPoints += 4);

                Debug.Log(boxPoints);

                Boxes[i].transform.position = transform.position;
                Boxes[i].SetActive(true);
                break;


            }

            /*if(Boxes[i].gameObject.tag == "Box1") {


                Debug.Log(pointsTest);


                Boxes[i].transform.position = transform.position;
                Boxes[randomBox].SetActive(true);
                scoreSystem.scoreText.text = "Score: " + (pointsTest += 1).ToString();

                break;

            }else if (Boxes[i].gameObject.tag == "Box2" ) {

                Debug.Log(pointsTest);


                Boxes[i].transform.position = transform.position;
                Boxes[randomBox].SetActive(true);
                scoreSystem.scoreText.text = "Score: " + (pointsTest += 1).ToString();

                break;


            }else if (Boxes[i].gameObject.tag == "Box3" ) {

                Debug.Log(pointsTest);


                Boxes[i].transform.position = transform.position;
                Boxes[randomBox].SetActive(true);
                scoreSystem.scoreText.text = "Score: " + (pointsTest += 1).ToString();

                break;

            }else if (Boxes[i].gameObject.tag == "Box4" ) {

                Debug.Log(pointsTest);


                Boxes[i].transform.position = transform.position;
                Boxes[randomBox].SetActive(true);
                scoreSystem.scoreText.text = "Score: " + (pointsTest += 1).ToString();

                break;


            }*/

        }

	}

    // Update is called once per frame
    void Update() {

        randomBox = Random.Range(0, 8);
        scoreSystem.text = "Score: " + boxPoints.ToString();


    }
}
