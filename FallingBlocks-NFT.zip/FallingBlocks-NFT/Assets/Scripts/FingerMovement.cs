using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class FingerMovement : MonoBehaviour, IPointerDownHandler , IDragHandler, IPointerUpHandler {

    // Start is called before the first frame update

    Vector2 startingPaddlePosition = Vector2.zero;
    Vector2 currentPaddlePosition = Vector2.zero;
    Vector2 returningPaddlePosition = Vector2.zero;

    public void OnPointerDown(PointerEventData eventData) {

        startingPaddlePosition = eventData.position;

	}

    public void OnDrag(PointerEventData eventData) {


        Debug.Log("dragging...");

        currentPaddlePosition = (eventData.position - startingPaddlePosition);

        Debug.Log(currentPaddlePosition.normalized + " ...");

    }

    

    public void OnPointerUp(PointerEventData eventData){

        Debug.Log("stopped dragging...");

        currentPaddlePosition = Vector2.zero;

    }

    public Vector2 PaddlePositionReturn() {

        returningPaddlePosition = currentPaddlePosition;

        return returningPaddlePosition;

	}



}
