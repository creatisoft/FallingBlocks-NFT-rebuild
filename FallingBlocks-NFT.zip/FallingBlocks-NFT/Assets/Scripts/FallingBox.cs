using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class FallingBox : MonoBehaviour {

    

    
    //public TextMeshProUGUI scoreSystem;


    // Start is called before the first frame update

    void Start() {

   

    }


    // Update is called once per frame
    void Update() {


        //adjust each box to a different raycast length.
        //


        /*Debug.DrawRay(transform.position, Vector2.down * 3.5f, Color.red);

        //int LayerMask = LayerMask.mak

        int paddleMask = LayerMask.GetMask("PaddleLayer");

        RaycastHit2D myHit = Physics2D.Raycast(transform.position, Vector2.down, 3.5f,  LayerMask.NameToLayer("PaddleLayer"));

        if (myHit.collider != null) {
            
            if(myHit.transform.tag == "Paddle") {

                //Debug.Log("hit paddle........");
			}


		}*/


    }


    private void OnCollisionEnter2D(Collision2D collision) {


        /*if (collision.gameObject.tag == "Box1") {

            Debug.Log("Fell off");

            //boxSpawnerPoints.scoreSystem.text = "Score: " + (boxSpawnerPoints.debugPoints =- 1).ToString();

        }
        if (collision.gameObject.tag == "Box2") {

            Debug.Log("Fell off");

            //boxSpawnerPoints.scoreSystem.text = "Score: " + (boxSpawnerPoints.debugPoints = -1).ToString();

        }
        if (collision.gameObject.tag == "Box3") {

            Debug.Log("Fell off");

            //boxSpawnerPoints.scoreSystem.text = "Score: " + (boxSpawnerPoints.debugPoints = -1).ToString();

        }
        if (collision.gameObject.tag == "Box4") {

            Debug.Log("Fell off");

            //boxSpawnerPoints.scoreSystem.text = "Score: " + (boxSpawnerPoints.debugPoints = -1).ToString();

        }*/
    }
}