using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class ScoreSystem : MonoBehaviour {

    public ScoreSystem scoreText;

    // Start is called before the first frame update
    void Start() {

    }

    // Update is called once per frame
    void Update() {



    }


    private void OnCollisionEnter2D(Collision2D collision)
    {


        /*if(collision.gameObject.tag == "Box1") {


           Debug.Log("box 1 has landed on paddle...");
            points = points - 1;


        }
        if (collision.gameObject.tag == "Box2") {

           Debug.Log("box 2 has landed paddle...");
           points = points - 2;


        }
        if (collision.gameObject.tag == "Box3") {

           Debug.Log("box 3 has landed paddle...");
           points = points - 3;

        }
        if (collision.gameObject.tag == "Box4") {

           Debug.Log("box 4 has landed paddle...");
           points = points - 4;

        }*/


    }


}
